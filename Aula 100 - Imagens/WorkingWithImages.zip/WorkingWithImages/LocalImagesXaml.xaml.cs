﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace WorkingWithImages
{
    public partial class LocalImagesXaml : ContentPage
    {
        public LocalImagesXaml()
        {
            InitializeComponent();
        }
    }
}
