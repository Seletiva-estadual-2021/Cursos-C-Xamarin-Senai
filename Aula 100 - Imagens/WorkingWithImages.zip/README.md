---
name: Working with Images
description: These samples relate to the [Working with Images in Xamarin.Forms](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/working-with/im...
topic: sample
languages:
- csharp
products:
- xamarin
technologies:
- xamarin-forms
urlFragment: workingwithimages
---
Working with Images
==============

These samples relate to the [Working with Images in Xamarin.Forms](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/working-with/images) doc.

![screenshot](https://raw.githubusercontent.com/xamarin/xamarin-forms-samples/master/WorkingWithImages/Screenshot/Images-sml.png "Colors")


Author
------

Craig Dunn
